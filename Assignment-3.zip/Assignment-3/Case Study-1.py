# -*- coding: utf-8 -*-
"""
Created on Thu Nov 17 08:29:35 2022

@author: badru
"""

e